# PRJ lib

It's a package to build the directories in a project structure. 